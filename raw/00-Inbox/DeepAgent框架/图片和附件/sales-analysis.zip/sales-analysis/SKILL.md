---
name: sales-analysis
description: 用于分析销售类 Excel、CSV 或 TSV 数据，并生成中文业务结论、KPI 拆解、趋势分析、异常识别和结构化销售报告。当智能体需要读取销售台账、订单明细、区域业绩表、产品销量表、销售人员绩效表，或根据表格数据输出经营分析结论时使用此 Skill。
---

# 销售分析 Skill

当任务涉及销售类表格数据理解、经营分析或结构化业务报告生成时，应使用此 Skill。

## 工作目标

使用此 Skill 时，应优先完成以下任务：

- 从销售表中提取并计算核心经营指标
- 按区域、产品、渠道、销售人员等维度进行拆解
- 识别趋势、异常、集中度风险和数据质量问题
- 根据分析结果输出结构化中文报告

## 执行流程

1. 先确认文件路径、文件类型和工作表名称，并检查表头与前几行样例，识别真实业务字段。
2. 先阅读 [references/kpi_definition.md](references/kpi_definition.md) 和 [references/analysis_rules.md](references/analysis_rules.md)，统一指标口径与分析规则。
3. 需要计算 KPI、分组汇总、月度趋势或异常识别时，优先调用 [scripts/analyze_excel.py](scripts/analyze_excel.py)。
4. 调用脚本时优先补齐关键参数，如 `--file`、`--sheet`、`--date-column`、`--revenue-column`、`--quantity-column` 和 `--group-fields`。
5. 如果环境缺少 `pandas`、`openpyxl` 等依赖，先在当前 sandbox 中安装，再重新执行脚本。
6. 脚本执行成功后，优先使用其结构化结果继续回答，包括 `detected_columns`、`kpis`、`top_breakdowns`、`monthly_trend`、`anomalies` 和 `anomaly_details`。
7. 如果脚本结果已经覆盖任务所需内容，不要重复编写新的 pandas 脚本；只有脚本确实无法覆盖需求时，才补充额外代码。
8. 输出正式报告时，使用 [assets/report_template.md](assets/report_template.md) 组织结果。

## 输入处理原则

- 支持 `.xlsx`、`.xls`、`.csv`、`.tsv`。
- 优先识别业务含义明确的列，不要依赖模糊猜测。
- 当表头不规范时，优先显式指定关键列。
- 在做分组比较前，先统一日期、数值、区域、产品和人员名称格式。
- 缺少某个指标所需字段时，明确说明限制，并继续输出其余可成立的分析结果。
- 如果运行环境缺少依赖，应先补齐依赖，再重新执行分析流程。

## 常见业务字段

优先识别以下字段：

- 日期、下单日期、交易日期
- 订单号、交易号
- 区域、大区、城市、门店
- 产品、商品、SKU、品类
- 销售人员、客户经理、负责人
- 销量、数量、件数
- 单价、金额、销售额、收入
- 成本、利润
- 客户、渠道

当多个字段都可能对应同一个业务含义时，选择业务语义最清晰的字段，并在结论中说明假设。

## 脚本调用规则

当任务包含以下任一内容时，优先调用 [scripts/analyze_excel.py](scripts/analyze_excel.py)：

- 计算总销售额、订单数、销量、利润、客单价等核心 KPI
- 输出按区域、产品、销售人员等维度的销售额汇总
- 生成月度趋势数据
- 检测负值、缺失值、重复订单等基础异常

调用脚本时遵循以下规则：

调用脚本时遵循以下规则：

- 多工作表文件先确认目标工作表；已知真实表头时，首次执行尽量一次性传入关键参数，避免反复试探。
- 如果自动识别不稳定，显式指定关键列，如 `--sheet`、`--date-column`、`--revenue-column`、`--quantity-column`、`--group-fields`。
- 如果运行环境缺少 `pandas`、`openpyxl` 等依赖，先在当前 sandbox 中安装，再重新执行脚本；只有无法安装时，才说明环境限制。
- 脚本成功返回结构化结果后，必须优先基于这些结果继续分析和回答，包括 `kpis`、`top_breakdowns`、`monthly_trend`、`anomalies` 和 `anomaly_details`。
- 如果脚本结果已经覆盖所需内容，不要再次编写临时 pandas 脚本，也不要重复计算相同的 KPI、分组汇总、趋势结果或异常明细。
- 只有在脚本结果确实缺少用户所需内容，且无法通过补充参数或重试脚本获得时，才允许补写额外代码。
- 命令应根据当前任务中的真实文件路径、工作表名称和列名动态组装，不要硬编码具体业务文件名。

建议优先使用类似以下方式调用脚本，并显式传入关键字段：

```powershell
python3 /workspace/skills/sales-analysis/scripts/analyze_excel.py --file <数据文件路径> --sheet <工作表名称> --date-column <日期列名> --revenue-column <销售额列名> --quantity-column <销量列名> --group-fields region product salesperson channel
```

## 分析优先级

- 先给出总体指标，再解释结构构成。
- 先给出数据事实，再做谨慎解释。
- 先指出影响经营判断的主要发现，再补充次要观察。
- 先指出异常和风险，再给出建议动作。

## 输出要求

面向业务方输出时，优先使用以下结构：

1. 执行摘要
2. KPI 快照
3. 趋势分析
4. 分维度拆解
5. 异常与风险
6. 建议动作

除非用户另有要求，否则优先沿用模板，并保持结论具体、谨慎、可追溯。
