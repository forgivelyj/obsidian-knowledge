from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable


# 维护一套“标准业务字段 -> 常见表头候选值”的映射。
# 这样脚本在面对不同来源的销售表时，可以先自动识别字段，
# 再把识别结果交给上层智能体组织分析结论。
CANONICAL_FIELDS = {
    "date": [
        "date",
        "order date",
        "order_date",
        "transaction date",
        "日期",
        "下单日期",
        "交易日期",
        "销售日期",
    ],
    "order_id": [
        "order id",
        "order_id",
        "transaction id",
        "订单号",
        "订单编号",
        "交易号",
        "单号",
    ],
    "region": [
        "region",
        "area",
        "city",
        "store",
        "区域",
        "大区",
        "省区",
        "城市",
        "门店",
    ],
    "product": [
        "product",
        "sku",
        "category",
        "item",
        "产品",
        "商品",
        "sku编码",
        "品类",
        "型号",
    ],
    "salesperson": [
        "salesperson",
        "owner",
        "account manager",
        "sales",
        "销售人员",
        "销售",
        "客户经理",
        "负责人",
        "业务员",
    ],
    "quantity": ["quantity", "qty", "units", "销量", "数量", "件数", "销售数量"],
    "revenue": [
        "revenue",
        "sales",
        "amount",
        "gmv",
        "销售额",
        "销售金额",
        "金额",
        "收入",
        "成交金额",
    ],
    "cost": ["cost", "成本", "销售成本", "成本金额"],
    "profit": ["profit", "gross profit", "利润", "毛利", "盈利"],
    "channel": ["channel", "渠道", "销售渠道", "来源渠道"],
    "customer": ["customer", "client", "客户", "客户名称", "客户名"],
}


def _import_pandas():
    """按需导入 pandas。

    该 skill 在 deepAgent 中运行时，依赖是否齐全取决于 sandbox 环境。
    因此这里不在模块导入阶段直接失败，而是在真正需要处理数据时再检查。
    一旦缺少依赖，就返回清晰的错误信息，方便智能体判断下一步是
    安装依赖、切换环境，还是直接向用户说明限制。

    这样设计还有一个直接好处：
    即使智能体在第一次执行脚本时发现缺少依赖，也可以在同一个任务流程里
    先执行安装命令，再次调用脚本，而不需要修改脚本源码。
    """
    try:
        import pandas as pd  # type: ignore
    except ImportError as exc:  # pragma: no cover - 是否安装依赖由运行环境决定
        raise SystemExit(
            "运行该脚本需要 pandas；分析 Excel 文件时通常还需要 openpyxl。"
        ) from exc
    return pd


def normalize_header(value: str) -> str:
    """标准化表头字符串，降低字段自动识别失败的概率。

    处理逻辑：
    1. 转成字符串
    2. 去除首尾空白
    3. 转小写
    4. 将下划线替换为空格
    5. 合并连续空格

    例如：
    - `Order_Date` -> `order date`
    - ` SALES ` -> `sales`
    """
    return " ".join(str(value).strip().lower().replace("_", " ").split())


def find_column(columns: Iterable[str], candidates: Iterable[str]) -> str | None:
    """在真实列名列表中查找某个标准业务字段对应的最佳匹配列。"""
    normalized = {normalize_header(column): column for column in columns}
    for candidate in candidates:
        match = normalized.get(normalize_header(candidate))
        if match:
            return match
    return None


def load_table(file_path: Path, sheet_name: str | None):
    """根据文件扩展名加载表格数据，并返回实际使用的工作表名称。

    支持 `.csv`、`.tsv`、`.xlsx`、`.xls`。
    如果是 Excel 文件，则允许通过 `sheet_name` 指定工作表。
    """
    pd = _import_pandas()
    suffix = file_path.suffix.lower()

    if suffix == ".csv":
        return pd.read_csv(file_path), None
    if suffix == ".tsv":
        return pd.read_csv(file_path, sep="\t"), None
    if suffix in {".xlsx", ".xls"}:
        if sheet_name:
            return pd.read_excel(file_path, sheet_name=sheet_name), sheet_name

        workbook = pd.read_excel(file_path, sheet_name=None)
        if not isinstance(workbook, dict) or not workbook:
            raise SystemExit("Excel 文件中未读取到任何工作表。")

        first_sheet_name = next(iter(workbook.keys()))
        return workbook[first_sheet_name], first_sheet_name

    raise SystemExit(f"不支持的文件类型: {suffix}")


def coerce_numeric(series):
    """尽量把金额、数量等字段转换为数值。

    销售报表中常见问题包括：
    - 数字被存成文本
    - 带千分位逗号
    - 存在空字符串

    无法安全转换的值将被置为 NaN，以免脏数据直接进入统计结果。
    """
    pd = _import_pandas()

    if series is None:
        return None

    if getattr(series, "dtype", None) is not None and str(series.dtype).startswith(("int", "float")):
        return series

    cleaned = series.astype(str).str.replace(",", "", regex=False).str.strip()
    return pd.to_numeric(cleaned, errors="coerce")


def summarize_by_group(
    df,
    group_column: str,
    revenue_column: str,
    quantity_column: str | None,
    profit_column: str | None,
    order_id_column: str | None,
    top_n: int,
):
    """按指定维度输出更完整的经营汇总。

    之前这里只返回按销售额排序的前 N 名，信息量偏少，智能体在需要输出
    “区域维度的销售额、订单数、销量、利润”这类更完整分析时，容易再写
    一段 pandas groupby 来补算。

    现在直接把常用维度指标一起返回，让脚本本身更接近业务分析所需的最小闭环。
    """
    grouped = df.groupby(group_column, dropna=False)

    summary_rows = []
    for group_name, group_df in grouped:
        revenue = float(group_df[revenue_column].sum(skipna=True))
        orders = (
            int(group_df[order_id_column].nunique())
            if order_id_column and order_id_column in group_df.columns
            else int(len(group_df))
        )
        quantity = (
            float(group_df[quantity_column].sum(skipna=True))
            if quantity_column and quantity_column in group_df.columns
            else None
        )
        profit = (
            float(group_df[profit_column].sum(skipna=True))
            if profit_column and profit_column in group_df.columns
            else None
        )

        summary_rows.append(
            {
                "name": str(group_name),
                "revenue": round(revenue, 2),
                "orders": orders,
                "quantity": round(quantity, 2) if quantity is not None else None,
                "profit": round(profit, 2) if profit is not None else None,
                "average_order_value": round(revenue / orders, 2) if orders else None,
                "profit_margin": round(profit / revenue, 4) if profit is not None and revenue else None,
            }
        )

    summary_rows.sort(key=lambda item: item["revenue"], reverse=True)
    return summary_rows[:top_n]


def normalize_group_fields(raw_group_fields: list[str] | None) -> list[str]:
    """兼容智能体可能传入的不同 group-fields 形态。"""
    if not raw_group_fields:
        return []

    normalized_fields: list[str] = []
    for item in raw_group_fields:
        for chunk in str(item).replace(",", " ").split():
            field_name = normalize_header(chunk).replace(" ", "_")
            if field_name and field_name not in normalized_fields:
                normalized_fields.append(field_name)

    return normalized_fields


def monthly_trend(df, date_column: str, revenue_column: str):
    """按月汇总销售额，生成趋势数据。"""
    pd = _import_pandas()

    dated = df.dropna(subset=[date_column]).copy()
    if dated.empty:
        return []

    dated[date_column] = pd.to_datetime(dated[date_column], errors="coerce")
    dated = dated.dropna(subset=[date_column])
    if dated.empty:
        return []

    dated["month"] = dated[date_column].dt.to_period("M").astype(str)
    trend = dated.groupby("month")[revenue_column].sum().sort_index()

    return [{"month": month, "revenue": round(float(value), 2)} for month, value in trend.items()]


def _safe_scalar(value):
    """把 pandas / numpy 标量转换成更稳定的 JSON 可序列化值。

    这里不追求保留所有底层类型信息，而是优先保证：
    1. 结果能被 `json.dumps` 正常输出
    2. 数值、字符串、日期这类业务常见值尽量可读
    3. 缺失值统一输出为 `None`
    """
    pd = _import_pandas()

    if pd.isna(value):
        return None
    if hasattr(value, "isoformat"):
        try:
            return value.isoformat()
        except TypeError:
            pass
    if hasattr(value, "item"):
        try:
            return value.item()
        except (ValueError, TypeError):
            pass
    return value


def _build_record_snapshot(df, row_indexes: list[int], fields: dict[str, str | None], extra_columns: list[str]):
    """根据行号提取异常明细快照。

    返回给智能体的不是整行原始数据，而是围绕销售分析最有用的字段子集，
    这样既能支持后续中文结论生成，也能避免输出过于臃肿。
    """
    columns_to_include: list[str] = []

    for field_name in [
        "order_id",
        "date",
        "region",
        "product",
        "salesperson",
        "channel",
        "customer",
        "quantity",
        "revenue",
        "cost",
        "profit",
    ]:
        column_name = fields.get(field_name)
        if column_name and column_name in df.columns and column_name not in columns_to_include:
            columns_to_include.append(column_name)

    for column_name in extra_columns:
        if column_name and column_name in df.columns and column_name not in columns_to_include:
            columns_to_include.append(column_name)

    snapshots = []
    for row_index in row_indexes:
        row = df.loc[row_index]
        record = {"row_index": int(row_index) + 2}
        for column_name in columns_to_include:
            record[column_name] = _safe_scalar(row[column_name])
        snapshots.append(record)

    return snapshots


def detect_anomalies(
    df,
    revenue_column: str,
    profit_column: str | None,
    order_id_column: str | None,
    fields: dict[str, str | None],
):
    """识别基础异常项，并同时返回摘要与明细。

    之前脚本只返回类似“发现 1 行销售额为负值”的摘要，
    这会让上层智能体在用户继续追问“具体是哪几行”时，倾向于再写一段
    pandas 代码去二次筛选。

    现在这里直接补齐异常明细，让智能体优先消费脚本结果，而不是重复算一遍。
    """
    issues: list[str] = []
    details: dict[str, list[dict[str, object]]] = {}

    negative_revenue = int((df[revenue_column] < 0).sum()) if revenue_column in df else 0
    if negative_revenue:
        issues.append(f"发现 {negative_revenue} 行销售额为负值。")
        negative_revenue_rows = df.index[df[revenue_column] < 0].tolist()
        details["negative_revenue"] = _build_record_snapshot(
            df,
            negative_revenue_rows,
            fields,
            [revenue_column],
        )

    if profit_column and profit_column in df:
        negative_profit = int((df[profit_column] < 0).sum())
        if negative_profit:
            issues.append(f"发现 {negative_profit} 行利润为负值。")
            negative_profit_rows = df.index[df[profit_column] < 0].tolist()
            details["negative_profit"] = _build_record_snapshot(
                df,
                negative_profit_rows,
                fields,
                [profit_column],
            )

    if order_id_column and order_id_column in df:
        duplicates = int(df[order_id_column].duplicated().sum())
        if duplicates:
            issues.append(f"发现 {duplicates} 条重复订单号记录。")
            duplicate_rows = df.index[df[order_id_column].duplicated(keep=False)].tolist()
            details["duplicate_orders"] = _build_record_snapshot(
                df,
                duplicate_rows,
                fields,
                [order_id_column],
            )

    missing_revenue = int(df[revenue_column].isna().sum())
    if missing_revenue:
        issues.append(f"发现 {missing_revenue} 行销售额缺失。")
        missing_revenue_rows = df.index[df[revenue_column].isna()].tolist()
        details["missing_revenue"] = _build_record_snapshot(
            df,
            missing_revenue_rows,
            fields,
            [revenue_column],
        )

    return {"summary": issues, "details": details}


def build_parser() -> argparse.ArgumentParser:
    """构建命令行参数解析器。

    该脚本主要由智能体在 sandbox 中调用，因此参数设计应服务于
    “自动化调用 + 必要时显式覆盖”的场景，而不是纯人工交互。

    参数设计原则如下：
    1. `--file` 和 `--sheet` 负责定位数据源
    2. `--date-column`、`--revenue-column`、`--quantity-column` 用于覆盖自动识别
    3. `--group-fields` 传入的是标准业务字段名，而不是原始表头
    4. `--top-n` 控制输出规模，避免结果过长，方便上层智能体继续总结
    """
    parser = argparse.ArgumentParser(description="分析销售类 Excel、CSV 或 TSV 数据。")
    parser.add_argument("--file", required=True, help="待分析文件路径")
    parser.add_argument("--sheet", help="Excel 工作表名称；仅对 Excel 文件生效")
    parser.add_argument("--date-column", help="手动指定日期列真实列名")
    parser.add_argument("--revenue-column", help="手动指定销售额列真实列名")
    parser.add_argument("--quantity-column", help="手动指定销量列真实列名")
    parser.add_argument(
        "--group-fields",
        nargs="*",
        default=["region", "product", "salesperson"],
        help="指定要汇总的标准业务字段名，例如 region product salesperson",
    )
    parser.add_argument("--top-n", type=int, default=5, help="每个维度返回前 N 名")
    return parser


def main() -> None:
    """脚本主入口。

    主流程：
    1. 解析参数
    2. 加载文件
    3. 识别业务字段
    4. 转换关键数值列
    5. 计算 KPI
    6. 输出分组汇总和趋势
    7. 检测异常
    8. 以 JSON 形式输出结构化结果
    """
    parser = build_parser()
    args = parser.parse_args()

    file_path = Path(args.file)
    if not file_path.exists():
        raise SystemExit(f"文件不存在: {file_path}")

    df, resolved_sheet_name = load_table(file_path, args.sheet)
    if df.empty:
        raise SystemExit("输入文件中没有可分析的数据行。")

    # 删除整行全空的数据，避免影响总行数、汇总和异常检测。
    df = df.dropna(how="all").copy()

    # 先尝试自动识别各类标准业务字段。
    fields: dict[str, str | None] = {}
    for key, candidates in CANONICAL_FIELDS.items():
        fields[key] = find_column(df.columns, candidates)

    # 如果上层智能体已经通过预览数据、读取表头或结合业务语义
    # 确认了真实列名，则优先使用显式传入的参数覆盖自动识别结果。
    # 这样可以减少因为表头命名特殊而导致的误识别。
    if args.date_column:
        fields["date"] = args.date_column
    if args.revenue_column:
        fields["revenue"] = args.revenue_column
    if args.quantity_column:
        fields["quantity"] = args.quantity_column

    revenue_column = fields["revenue"]
    if not revenue_column or revenue_column not in df.columns:
        raise SystemExit("未能识别销售额列，请通过 --revenue-column 手动指定。")

    df[revenue_column] = coerce_numeric(df[revenue_column])

    quantity_column = fields["quantity"]
    if quantity_column and quantity_column in df.columns:
        df[quantity_column] = coerce_numeric(df[quantity_column])

    # 利润优先使用原始利润列；如果没有利润列但有成本列，则自动推导利润。
    profit_column = fields["profit"]
    if profit_column and profit_column in df.columns:
        df[profit_column] = coerce_numeric(df[profit_column])
    else:
        cost_column = fields["cost"]
        if cost_column and cost_column in df.columns:
            df[cost_column] = coerce_numeric(df[cost_column])
            profit_column = "__derived_profit__"
            df[profit_column] = df[revenue_column] - df[cost_column]

    # 订单数优先按订单号去重；如果没有订单号，则退化为按行数统计。
    order_id_column = fields["order_id"] if fields["order_id"] in df.columns else None

    total_revenue = float(df[revenue_column].sum(skipna=True))
    total_orders = int(df[order_id_column].nunique()) if order_id_column else int(len(df))
    total_quantity = (
        float(df[quantity_column].sum(skipna=True))
        if quantity_column and quantity_column in df.columns
        else None
    )
    gross_profit = (
        float(df[profit_column].sum(skipna=True))
        if profit_column and profit_column in df.columns
        else None
    )

    kpis = {
        "total_revenue": round(total_revenue, 2),
        "total_orders": total_orders,
        "average_order_value": round(total_revenue / total_orders, 2) if total_orders else None,
        "total_quantity": round(total_quantity, 2) if total_quantity is not None else None,
        "gross_profit": round(gross_profit, 2) if gross_profit is not None else None,
        "profit_margin": round(gross_profit / total_revenue, 4)
        if gross_profit is not None and total_revenue
        else None,
    }

    normalized_group_fields = normalize_group_fields(args.group_fields)

    # group_fields 传入的是标准业务字段名，不是原始列名；
    # 因此这里需要先通过自动识别结果映射到真实列名，再执行分组汇总。
    breakdowns = {}
    for group_field in normalized_group_fields:
        actual_column = fields.get(group_field)
        if actual_column and actual_column in df.columns:
            breakdowns[group_field] = summarize_by_group(
                df,
                actual_column,
                revenue_column,
                quantity_column,
                profit_column,
                order_id_column,
                args.top_n,
            )

    trend = []
    if fields["date"] and fields["date"] in df.columns:
        trend = monthly_trend(df, fields["date"], revenue_column)

    anomalies = detect_anomalies(df, revenue_column, profit_column, order_id_column, fields)

    # 输出结果保持 JSON 结构化，便于上层智能体继续做两类工作：
    # 1. 直接抽取 KPI、趋势、异常等结果生成中文结论
    # 2. 在多轮分析中把本次结果作为中间状态继续加工
    result = {
        "file": str(file_path),
        "sheet": resolved_sheet_name,
        "row_count": int(len(df)),
        "detected_columns": fields,
        "requested_group_fields": normalized_group_fields,
        "kpis": kpis,
        "top_breakdowns": breakdowns,
        "monthly_trend": trend,
        "anomalies": anomalies["summary"],
        "anomaly_details": anomalies["details"],
    }

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
